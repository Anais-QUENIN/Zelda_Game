===============================
HOW TO RUN THE TUTORIAL EXAMPLE
===============================

1. Execute RUN.bat script

2. Click the tutorial you want to run







