package zelda;

public enum Orientation {
    SOUTH,
    WEST,
    EAST, 
    NORTH,
    NORTH_EAST,
    NORTH_WEST,
    SOUTH_EAST,
    SOUTH_WEST
}
