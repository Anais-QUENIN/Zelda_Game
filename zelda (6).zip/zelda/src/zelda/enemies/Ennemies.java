package zelda.enemies;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;
import com.golden.gamedev.object.AnimatedSprite;
import com.golden.gamedev.object.CollisionManager;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.object.SpriteGroup;
import com.golden.gamedev.object.Timer;
import com.golden.gamedev.object.collision.AdvanceCollisionGroup;

import zelda.Link;
import zelda.Orientation;
import zelda.Zelda;
import zelda.objects.Shield;
import zelda.scenary.Board;

public abstract class Ennemies extends AnimatedSprite{

	
	protected static double SPEED = 0.1;  
	    
	protected static final int ANIMATION_DELAY = 100;  
	    
	protected static final int FIGHT_TIMER = 300;
	
	protected int life;
    
    protected Timer figth;
    
    protected int dommages=1;
    
    protected CollisionManager manager;
    
    protected CollisionManager ennemiesEnnemy;
    
    protected Orientation orientation;
    
    protected Zelda game;
    
    protected Board board;
    
    
    
    protected int timeSinceLastShot = 0;
	protected final int SHOT_INTERVAL = 1000;
	protected final int REPULSED_TIMER = 50;
	protected final double REPULSED_SPEED = 0.5;
	
	protected double repulsedTimer = 0;
	protected double repulsedSpeed = REPULSED_SPEED;
	protected double xRepulse = 0, yRepulse=0;
	protected int onceTimer = 100;
    
    public Board getBoard() {
    	return this.board;
    }
    
    public static BufferedImage toBufferedImage(Image img)
    {
        if (img instanceof BufferedImage)
        {
            return (BufferedImage) img;
        }

        // Create a buffered image with transparency
        BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);

        // Draw the image on to the buffered image
        Graphics2D bGr = bimage.createGraphics();
        bGr.drawImage(img, 0, 0, null);
        bGr.dispose();

        // Return the buffered image
        return bimage;
    }
    
public void changeOrientation() {
		
		switch(this.orientation) {
		case NORTH: this.orientation=orientation.SOUTH;
		case SOUTH: this.orientation=orientation.NORTH;
		case EAST: this.orientation=orientation.WEST;
		case WEST: this.orientation=orientation.EAST;
		case NORTH_EAST: this.orientation=orientation.SOUTH_WEST;
		case NORTH_WEST: this.orientation=orientation.SOUTH_EAST;
		case SOUTH_EAST: this.orientation=orientation.NORTH_WEST;
		case SOUTH_WEST: this.orientation=orientation.NORTH_EAST;
		}
	}
    
    public Boolean SortTableau() {
    	if (this.getX()<0 || this.getX()>672 || this.getY()<126 || this.getY()>588) {
    	return true;
    	
    	}else return false;
    }
    
    public void setOrientation(Orientation orientation) {
    	this.orientation=orientation;
    }
    
    public Orientation getOrientation() {
    	return this.orientation;
    }
    
    public int Dommages(int dommages) {
    	return life -= dommages;
        
    }
    
    public boolean meurt() {
    	if(life<=0) {
    		return true;
    	}
    	else return false;
    }
	
    public int getDommages() {
    	return this.dommages;
    }
    
    boolean once = false;
    
    public void repulse(Link link) {
    	if(!once) {
    	repulsedTimer = REPULSED_TIMER;
    	repulsedSpeed = REPULSED_SPEED;
    	double xv = (this.getX() - link.getX());
    	double yv = (this.getY() - link.getY());
    	xRepulse = xv / Math.sqrt((xv*xv)+yv*yv);
    	yRepulse = yv / Math.sqrt((xv*xv)+yv*yv);
    	once = true;
    	onceTimer = 100;
    	}
    }
    
	public void gauche() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(0, 1);
			this.setAnimate(true);
            this.setHorizontalSpeed(-this.SPEED);
            this.setVerticalSpeed(0);
            this.orientation = Orientation.WEST;
		}
	}
		
	public void droite() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(2, 3);
			this.setAnimate(true);
            this.setHorizontalSpeed(this.SPEED);
            this.setVerticalSpeed(0);
            this.orientation = Orientation.EAST;
		}
	}
	
	public void bas() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(4, 5);
			this.setAnimate(true);
            this.setHorizontalSpeed(0);
            this.setVerticalSpeed(this.SPEED);
            this.orientation = Orientation.SOUTH;
		}
	}
	
	public  void haut() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(6, 7);
			this.setAnimate(true);
            this.setHorizontalSpeed(0);
            this.setVerticalSpeed(-this.SPEED);
            this.orientation = Orientation.NORTH;
		}
	}
	
	
	
	public void render(Graphics2D g) {
        super.render(g);
    }

	
	public void setBoard(Board board) {
		this.board=board;
        SpriteGroup ennemies = new SpriteGroup("ENNEMIES SPRITE GROUPE");
        ennemies.add(this);
        this.ennemiesEnnemy.setCollisionGroup(ennemies, ennemies);
        this.manager.setCollisionGroup(ennemies, board.getForeground());
    }
	
	protected class EnnemiesCollisionManager extends AdvanceCollisionGroup {
        public EnnemiesCollisionManager() {
            this.pixelPerfectCollision = false;
        }
        
        public void collided(Sprite s1, Sprite s2) {
            
     
        
            this.revertPosition1();
        }
    }
	
	protected class EnnemiesEnnemyCollisionManager extends AdvanceCollisionGroup {
        public EnnemiesEnnemyCollisionManager() {
            this.pixelPerfectCollision = false;
        }
        
        public void collided(Sprite s1, Sprite s2) {
            
     
        	this.revertPosition2();
            this.revertPosition1();
        }
    }
	
	public boolean isRepulsed() {
		return this.repulsedTimer > 0;
	}
	
	@Override
	public void update(long elapsedTime) {
		super.update(elapsedTime);
		repulsedTimer = repulsedTimer - elapsedTime;
		if(!isRepulsed()) {
			repulsedSpeed = 0;
			
		}
		else {
			repulsedSpeed -= elapsedTime/REPULSED_TIMER*2;
			this.setSpeed(repulsedSpeed*xRepulse, repulsedSpeed*yRepulse);
		}
		if(once) {
			onceTimer -= elapsedTime;
			if(onceTimer <= 0)
				once = false;
		}
		
	}
	
	public abstract void fight(Board board, Link link);

	public Game getGame() {
		return game;
	}

	public void setGame(Zelda game) {
		this.game = game;
	}

}
