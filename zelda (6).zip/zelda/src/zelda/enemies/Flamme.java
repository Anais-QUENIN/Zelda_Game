package zelda.enemies;

import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.object.Timer;
import com.golden.gamedev.object.collision.AdvanceCollisionGroup;

import zelda.Link;
import zelda.Orientation;
import zelda.Zelda;
import zelda.enemies.Ennemies.EnnemiesCollisionManager;
import zelda.enemies.Ennemies.EnnemiesEnnemyCollisionManager;
import zelda.scenary.Board;

public class Flamme extends Ennemies{
	
	public Flamme(Zelda game,double x, double y) {
        this.setGame(game);
        this.getAnimationTimer().setDelay(Ennemies.ANIMATION_DELAY);
        this.figth = new Timer(Ennemies.FIGHT_TIMER);
        this.figth.setActive(false);
        this.orientation=orientation.SOUTH;
        this.ennemiesEnnemy= new EnnemiesEnnemyCollisionManager();
        this.manager = new EnnemiesCollisionManager();
        this.life=1;
        this.initResources(x,y);
    }
	
	public void update(long elapsedTime) {
super.update(elapsedTime);
        
        if (this.figth.action(elapsedTime)) {
            this.figth.setActive(false); 

            if(!isRepulsed()) {

            if (this.orientation.equals(Orientation.EAST)) {
            	

                this.setAnimationFrame(0, 1);
             
            } else if (this.orientation.equals(Orientation.WEST)) {

                this.setAnimationFrame(1, 0);
            }
      
            
        }
            
           
        }
        
        if (this.SortTableau()) {
        	System.out.println(this.getX() + "," + this.getY() + " vs " + this.getOldX() + "," + this.getOldY());
        	this.setX(this.getOldX());
        	this.setY(this.getOldY());
        	this.changeOrientation();
        } 

     if (this.manager != null) 
            this.manager.checkCollision();

            if(!isRepulsed()) {
            	
        Board lb = this.game.getLink().getBoard();
        Board b = this.getBoard();

         if(this.game.getLink().getBoard()==this.getBoard())    {
         ai();   

         
         }
            }
    }
	
	
	private void initResources(double x, double y) {
        BufferedImage[] sprites = new BufferedImage[8];
        sprites[0] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/flamme1.png").getScaledInstance(25, 25, 15));
        sprites[1] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/flamme2.png").getScaledInstance(25, 25, 15));
        sprites[2] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/flamme1.png").getScaledInstance(25, 25, 15));
        sprites[3] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/flamme2.png").getScaledInstance(25, 25, 15));
        sprites[4] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/flamme1.png").getScaledInstance(25, 25, 15));
        sprites[5] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/flamme2.png").getScaledInstance(25, 25, 15));
        sprites[6] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/flamme1.png").getScaledInstance(25, 25, 15));
        sprites[7] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/flamme2.png").getScaledInstance(25, 25, 15));
        this.setImages(sprites);
        this.setLocation(x, y);
        this.setAnimationFrame(0, 0);
    }

	@Override
	public void fight(Board board, Link link) {
		// TODO Auto-generated method stub
		
	}
	
	public void bas_droite() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(4, 5);
			this.setAnimate(true);
            this.setHorizontalSpeed(this.SPEED);
            this.setVerticalSpeed(this.SPEED);
            this.orientation = Orientation.SOUTH_EAST;
		}
	}
	
	public void bas_gauche() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(4, 5);
			this.setAnimate(true);
            this.setHorizontalSpeed(-this.SPEED);
            this.setVerticalSpeed(this.SPEED);
            this.orientation = Orientation.SOUTH_WEST;
		}
	}
	
	public void haut_droite() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(4, 5);
			this.setAnimate(true);
            this.setHorizontalSpeed(this.SPEED);
            this.setVerticalSpeed(-this.SPEED);
            this.orientation = Orientation.NORTH_EAST;
		}
	}
	
	public void haut_gauche() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(4, 5);
			this.setAnimate(true);
            this.setHorizontalSpeed(-this.SPEED);
            this.setVerticalSpeed(-this.SPEED);
            this.orientation = Orientation.NORTH_WEST;
		}
	}
	
	
	
	protected class EnnemiesCollisionManager extends AdvanceCollisionGroup {
	    public EnnemiesCollisionManager() {
	        this.pixelPerfectCollision = false;
	    }
	    
	  /*  public void collided(Sprite s1, Sprite s2) {
	        this.revertPosition1();
	        zelda.enemies.Ennemies Sennemi = (zelda.enemies.Ennemies) s1;
	        if(Sennemi.getOrientation() == Orientation.WEST) {
	        	Sennemi.setOrientation(Orientation.EAST);
	        }  if(Sennemi.getOrientation() == Orientation.EAST) {
	        	Sennemi.setOrientation(Orientation.WEST);
	    }*/
	    
	    public void collided(Sprite s1, Sprite s2) {
	    	this.revertPosition1();
	    	if (s1 instanceof Flamme) {
	            Flamme flamme = (Flamme) s1;
	            flamme.changeOrientation();
	        }
	    
	    
	    

	    } 
	    
	}
	
	public void changeOrientation() {
		
		switch(this.orientation) {
		case NORTH: this.orientation=orientation.SOUTH;
		case SOUTH: this.orientation=orientation.NORTH;
		case EAST: this.orientation=orientation.WEST;
		case WEST: this.orientation=orientation.EAST;
		case NORTH_EAST: this.orientation=orientation.SOUTH_WEST;
		case NORTH_WEST: this.orientation=orientation.SOUTH_EAST;
		case SOUTH_EAST: this.orientation=orientation.NORTH_WEST;
		case SOUTH_WEST: this.orientation=orientation.NORTH_EAST;
		}
	}
	
	public void ai() {
		this.manager.checkCollision();
		int indice=(int) (1 + (Math.random() * (8 - 1)));
		Orientation [] dir= {Orientation.SOUTH, Orientation.NORTH, Orientation.WEST, Orientation.EAST, Orientation.NORTH_EAST, Orientation.NORTH_WEST, Orientation.SOUTH_EAST, Orientation.SOUTH_WEST};
		Orientation or=dir[indice];
		switch(or) {
		case NORTH: this.haut();
		case SOUTH: this.bas();
		case EAST: this.droite();
		case WEST: this.gauche();
		case NORTH_EAST: this.haut_droite();
		case NORTH_WEST: this.haut_gauche();
		case SOUTH_EAST: this.bas_droite();
		case SOUTH_WEST: this.bas_gauche();
		}
	}

}
