package zelda.enemies;

import java.awt.Graphics2D;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.object.SpriteGroup;

import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;
import com.golden.gamedev.object.AnimatedSprite;
import com.golden.gamedev.object.CollisionManager;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.object.SpriteGroup;
import com.golden.gamedev.object.Timer;
import com.golden.gamedev.object.collision.AdvanceCollisionGroup;

import zelda.Orientation;
import zelda.scenary.Board;

public abstract class Projsimple extends AnimatedSprite {

	protected static double SPEED = 0.3;  
	    
	protected static final int ANIMATION_DELAY = 100;  
	    
	protected static final int FIGHT_TIMER = 300;
    
    protected Timer figth;
    
    protected CollisionManager manager;
    
    protected final Orientation orientation;
    
    protected Game game;
    
    protected SpriteGroup groupe;
    
    protected int dommages=2;
    
    public boolean alive;
    
    protected Board board;
    
	
    public abstract void initResources(double x, double y);
	
    public Board getBoard() {
    	return this.board;
    }
    
    public int getDommages() {
    	return this.dommages;
    }
	
    public Projsimple(Game game, Orientation orientation, double x, double y) {
        this.game = game;
        this.orientation = orientation;
        this.figth = new Timer(Ennemies.FIGHT_TIMER);
        this.figth.setActive(false);
        this.getAnimationTimer().setDelay(Projmage.ANIMATION_DELAY);
        this.alive=true;
        this.manager = new ProjCollisionManager();
        this.initResources(x,y);
    }
    
    public Orientation getOrientation() {
    	return this.orientation;
    }
    
    class ProjCollisionManager extends AdvanceCollisionGroup {
    	

		public ProjCollisionManager() {
            this.pixelPerfectCollision = false;
        }
        
        public void collided(Sprite s1, Sprite s2) {
        	zelda.enemies.Projsimple proj= (zelda.enemies.Projsimple)s1;
            proj.alive=false;
        	this.revertPosition1();
        	System.out.println("proj alive false");
        	
        }
            
    }
    
    public void setBoard(Board board) {
    	this.board=board;
    	this.groupe = new SpriteGroup("PROJ SPRITE GROUPE");
        this.groupe.add(this);
        this.manager.setCollisionGroup(this.groupe, board.getForeground());
    }
    
    public void update(long elapsedTime) {
    	super.update(elapsedTime);
        if (this.figth.action(elapsedTime)) {
            this.figth.setActive(false);
            if (this.orientation.equals(Orientation.WEST)) {
                this.setX(this.getX() + 22);
                this.setAnimationFrame(0, 1);
             
            } else if (this.orientation.equals(Orientation.NORTH)) {
                this.setY(this.getY() + 22);
                this.setAnimationFrame(0, 0);
            }
        }
        if (this.manager != null) 
            this.manager.checkCollision();
        
        	
    }

    
    public void render(Graphics2D g) {
    	if(this.alive)
        super.render(g);
    	else this.setX(-2);
    }

    
    public void shoot(Orientation direction) {
    	switch(direction) {
    	case NORTH: 
    		this.setAnimationFrame(0, 1);
    		this.setAnimate(true);
    		this.setVerticalSpeed(-Projsimple.SPEED);
    		this.setHorizontalSpeed(0);
    		break;
    	case SOUTH:
    		this.setAnimationFrame(0, 1);
    		this.setAnimate(true);
            this.setVerticalSpeed(Projsimple.SPEED);
            this.setHorizontalSpeed(0);
            break;
    	case EAST:
    		this.setAnimationFrame(0, 1);
    		this.setAnimate(true);
            this.setVerticalSpeed(0);
            this.setHorizontalSpeed(Projsimple.SPEED);
            break;
    	case WEST:
    		this.setAnimationFrame(0, 1);
    		this.setAnimate(true);
            this.setVerticalSpeed(0);
            this.setHorizontalSpeed(-Projsimple.SPEED);
            break;
    	}
    }
    
    
   
    }
