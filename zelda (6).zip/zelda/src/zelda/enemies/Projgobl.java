package zelda.enemies;

import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;

import zelda.Orientation;

public class Projgobl extends Projsimple{

	public Projgobl(Game game, Orientation orientation, double x, double y) {
		super(game, orientation, x, y);
	}

	@Override
	public void initResources(double x, double y) {
		 BufferedImage[] sprites = new BufferedImage[4];
	        sprites[0] = game.getImage("res/sprites/Objects/OWAE.gif");
	        sprites[1] = game.getImage("res/sprites/Objects/OWAW.gif");
	        sprites[2] = game.getImage("res/sprites/Objects/OWAN.gif");
	        sprites[3] = game.getImage("res/sprites/Objects/OWAS.gif");
	        this.setImages(sprites);
	        this.setLocation(x, y);
	        this.setAnimationFrame(0, 0);
		
	}

	@Override
	public void shoot(Orientation direction) {
    	switch(direction) {
    	case NORTH: 
    		this.setAnimationFrame(2, 2);
    		this.setAnimate(true);
    		this.setVerticalSpeed(-Projsimple.SPEED);
    		this.setHorizontalSpeed(0);
    		break;
    	case SOUTH:
    		this.setAnimationFrame(3, 3);
    		this.setAnimate(true);
            this.setVerticalSpeed(Projsimple.SPEED);
            this.setHorizontalSpeed(0);
            break;
    	case EAST:
    		this.setAnimationFrame(0, 0);
    		this.setAnimate(true);
            this.setVerticalSpeed(0);
            this.setHorizontalSpeed(Projsimple.SPEED);
            break;
    	case WEST:
    		this.setAnimationFrame(1, 1);
    		this.setAnimate(true);
            this.setVerticalSpeed(0);
            this.setHorizontalSpeed(-Projsimple.SPEED);
            break;
    	}
    }
}
