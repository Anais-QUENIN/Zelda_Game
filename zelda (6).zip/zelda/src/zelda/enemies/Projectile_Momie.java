package zelda.enemies;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;
import com.golden.gamedev.object.AnimatedSprite;
import com.golden.gamedev.object.CollisionManager;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.object.SpriteGroup;
import com.golden.gamedev.object.Timer;
import com.golden.gamedev.object.collision.AdvanceCollisionGroup;

import zelda.Orientation;
import zelda.objects.Shield;
import zelda.scenary.Board;


public class Projectile_Momie extends Projsimple {


    public Projectile_Momie(Game game, Orientation orientation, double x, double y) {
        super(game,orientation,x,y);
        this.manager=new ProjCollisionManager();
    }


    public void initResources(double x, double y) {
        BufferedImage[] sprites = new BufferedImage[2];
        sprites[0] = game.getImage("res/sprites/Ennemies/boule_feu_momie.png");
        sprites[1] = game.getImage("res/sprites/Ennemies/boule_feu_momie.png");
        this.setImages(sprites);
        this.setLocation(x, y);
        this.setAnimationFrame(0, 0);
    }

}