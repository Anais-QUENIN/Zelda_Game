package zelda.enemies;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;
import com.golden.gamedev.object.Timer;

import zelda.Link;
import zelda.Orientation;
import zelda.Zelda;
import zelda.enemies.Ennemies.EnnemiesEnnemyCollisionManager;
import zelda.objects.Shield;
import zelda.scenary.Board;
import zelda.scenary.Quest;


public class Mage extends Ennemies{

	
	protected Projmage projectile;
	
	public Projmage getProj() {
		return this.projectile;
	}
	
	public Mage(Zelda game, double x, double y) {
        this.setGame(game);
        this.getAnimationTimer().setDelay(Ennemies.ANIMATION_DELAY);
        this.figth = new Timer(Ennemies.FIGHT_TIMER);
        this.SPEED=0.05;
        this.figth.setActive(false);
        this.life=3;
        this.orientation=orientation.SOUTH;
        this.ennemiesEnnemy= new EnnemiesEnnemyCollisionManager();
        this.manager = new EnnemiesCollisionManager();
        this.initResources(x,y);
    }
	
	
	private void initResources(double x, double y) {
        BufferedImage[] sprites = new BufferedImage[8];
        sprites[0] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/magegauche.png").getScaledInstance(35, 25, 15));
        sprites[1] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/magedroite.png").getScaledInstance(35, 25, 15));
        sprites[2] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/magedroite.png").getScaledInstance(35, 25, 15));
        sprites[3] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/magegauche.png").getScaledInstance(35, 25, 15));
        sprites[4] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/magehaut.png").getScaledInstance(35, 25, 15));
        sprites[5] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/magehaut.png").getScaledInstance(35, 25, 15));
        sprites[6] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/magegauche.png").getScaledInstance(35, 25, 15));
        sprites[7] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/magedroite.png").getScaledInstance(35, 25, 15));
        this.setImages(sprites);
        this.setLocation(x, y);
        this.setAnimationFrame(0, 0);
    }
	
	public void update(long elapsedTime) {
super.update(elapsedTime);
        
        if (this.figth.action(elapsedTime)) {
            this.figth.setActive(false); 

            if(!isRepulsed()) {

            if (this.orientation.equals(Orientation.EAST)) {
            	

                this.setAnimationFrame(0, 1);
             
            } else if (this.orientation.equals(Orientation.WEST)) {

                this.setAnimationFrame(1, 0);
            }
      
            
        }
            
           
        }
        
        if (this.SortTableau()) {
        	System.out.println(this.getX() + "," + this.getY() + " vs " + this.getOldX() + "," + this.getOldY());
        	this.setX(this.getOldX());
        	this.setY(this.getOldY());
        	this.changeOrientation();
        } 

     if (this.manager != null) 
            this.manager.checkCollision();

            if(!isRepulsed()) {
            	
        Board lb = this.game.getLink().getBoard();
        Board b = this.getBoard();

         if(this.game.getLink().getBoard()==this.getBoard())    {
         ai(this.game.getLink());   

         
         }}
            }

    
    public void render(Graphics2D g) {
        super.render(g);
    }

	@Override
	public void fight(Board board, Link link) {
		
		int indice=(int) (1 + (Math.random() * (8 - 1)));
		Orientation [] dir= {Orientation.SOUTH, Orientation.NORTH, Orientation.WEST, Orientation.EAST, Orientation.NORTH_EAST, Orientation.NORTH_WEST, Orientation.SOUTH_EAST, Orientation.SOUTH_WEST};
		Orientation or=dir[indice];
		this.projectile= new Projmage(this.game, or, this.getX(),this.getY());
		this.projectile.setBoard(board);
		link.ennemies.add(projectile);
		projectile.shoot(or);
		board.addProjectile(projectile);

		}
	
public void fight(Board board, Link link, Orientation orientation) {
		
		int indice=(int) (1 + (Math.random() * (8 - 1)));
		this.projectile= new Projmage(this.game, orientation, this.getX(),this.getY());
		this.projectile.setBoard(board);
		link.ennemies.add(projectile);
		projectile.shoot(orientation);
		board.addProjectile(projectile);

		}
	
public void ai(Link link) {
		
		double dx = link.getX() - this.getX();
		double dy = link.getY() - this.getY();
		
		System.out.println(this.timeSinceLastShot + " vs " + this.SHOT_INTERVAL);
		if (timeSinceLastShot >= 500) {
	        // shoot at Link
	        this.fight(board, link, Orientation.NORTH);
	        this.fight(board, link, Orientation.SOUTH);
	        this.fight(board, link, Orientation.EAST);
	        this.fight(board, link, orientation.WEST);
	        this.fight(board, link, orientation.NORTH_EAST);
	        this.fight(board, link, orientation.NORTH_WEST);
	        this.fight(board, link, orientation.SOUTH_EAST);
	        this.fight(board, link, orientation.SOUTH_WEST);
	        timeSinceLastShot = 0;
	        System.out.println(this.timeSinceLastShot + " vs " + this.SHOT_INTERVAL + " entered");
	    } else {
	        timeSinceLastShot++;
	    }
		
    	if(Math.abs(dx)>Math.abs(dy)) {
        if (dx < 0) {
            this.gauche();
        } else if (dx > 0) {
            this.droite();
        }
    	}else {

        if (dy < 0) {
            this.haut();
        } else if (dy > 0) {
            this.bas();
        }
    }
		
	}
}


