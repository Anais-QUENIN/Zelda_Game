package zelda.enemies;

import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;
import com.golden.gamedev.object.Timer;

import zelda.Link;
import zelda.Orientation;
import zelda.Zelda;
import zelda.enemies.Ennemies.EnnemiesCollisionManager;
import zelda.enemies.Ennemies.EnnemiesEnnemyCollisionManager;
import zelda.scenary.Board;

public class Octo extends Ennemies{

	protected Projoct projectile;
	
	public Projoct getProj() {
		return this.projectile;
	}

	
	public Octo(Zelda game, double x, double y) {
        this.setGame(game);
        this.getAnimationTimer().setDelay(Ennemies.ANIMATION_DELAY);
        this.figth = new Timer(Ennemies.FIGHT_TIMER);
        this.figth.setActive(false);
        this.life=2;
        this.orientation=orientation.SOUTH;
        this.ennemiesEnnemy= new EnnemiesEnnemyCollisionManager();
        this.manager = new EnnemiesCollisionManager();
        this.initResources(x,y);
    }
	
	
	private void initResources(double x, double y) {
        BufferedImage[] sprites = new BufferedImage[8];
        sprites[0] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/octgauchecourt.png").getScaledInstance(35, 25, 15));;
        sprites[1] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/octgauchelong.png").getScaledInstance(35, 25, 15));;
        sprites[2] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/octdroitecourt.png").getScaledInstance(35, 25, 15));;
        sprites[3] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/octdroitelong.png").getScaledInstance(35, 25, 15));;
        sprites[4] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/octbascourt.png").getScaledInstance(35, 25, 15));;
        sprites[5] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/octbaslong.png").getScaledInstance(35, 25, 15));;
        sprites[6] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/octhautcourt.png").getScaledInstance(35, 25, 15));;
        sprites[7] = Ennemies.toBufferedImage(getGame().getImage("res/sprites/Ennemies/octhautlong.png").getScaledInstance(35, 25, 15));;
        this.setImages(sprites);
        this.setLocation(x, y);
        this.setAnimationFrame(4, 4);
    }
	
	public void update(long elapsedTime) {
        super.update(elapsedTime);
        if (this.figth.action(elapsedTime)) {
            this.figth.setActive(false);
            if (this.orientation.equals(Orientation.WEST)) {
                this.setX(this.getX() + 22);
                this.setAnimationFrame(0, 1);
             
            } else if (this.orientation.equals(Orientation.NORTH)) {
                this.setY(this.getY() + 22);
                this.setAnimationFrame(0, 0);
            }
        }
        if (this.SortTableau()) {
        	this.setX(this.getOldX());
        	this.setY(this.getOldY());
        }
        
        if(this.ennemiesEnnemy!=null) {
        	this.ennemiesEnnemy.checkCollision();
        }
        
        if(this.game.getLink().getBoard()==this.board)
        	ai(this.game.getLink());
        
        
        if (this.manager != null) 
            this.manager.checkCollision();
    }
	
	@Override
	public void fight(Board board, Link link) {
		this.projectile= new Projoct (this.game, this.orientation, this.getX(),this.getY());
		projectile.setBoard(board);
		link.ennemies.add(projectile);
		projectile.shoot(this.orientation);
		
		
	}
	
	public void fight(Board board, Link link, Orientation orientation) {
		this.projectile= new Projoct(this.game, orientation, this.getX(),this.getY());
		projectile.setBoard(board);
		link.ennemies.add(projectile);
		projectile.shoot(orientation);
		board.addProjectile(projectile);
		
		
	}
	
public void ai(Link link) {
		
	double dx = link.getX() - this.getX();
	double dy = link.getY() - this.getY();
	
	System.out.println(this.timeSinceLastShot + " vs " + this.SHOT_INTERVAL);
	if (timeSinceLastShot >= 100) {
        // shoot at Link
        this.fight(board, link, orientation);
        timeSinceLastShot = 0;
        System.out.println(this.timeSinceLastShot + " vs " + this.SHOT_INTERVAL + " entered");
    } else {
        timeSinceLastShot++;
    }
	
	if(Math.abs(dx)>Math.abs(dy)) {
    if (dx < 0) {
        this.gauche();
    } else if (dx > 0) {
        this.droite();
    }
	}else {

    if (dy < 0) {
        this.haut();
    } else if (dy > 0) {
        this.bas();
    }
}
}
	
	

}
