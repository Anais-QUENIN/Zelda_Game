package zelda.enemies;

import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;

import zelda.Orientation;

public class Projoct extends Projsimple{

	public Projoct(Game game, Orientation orientation, double x, double y) {
		super(game, orientation, x, y);
	}

	@Override
	public void initResources(double x, double y) {
		 BufferedImage[] sprites = new BufferedImage[2];
	        sprites[0] = game.getImage("res/sprites/Ennemies/projoct.png");
	        sprites[1] = game.getImage("res/sprites/Ennemies/projoct.png");
	        this.setImages(sprites);
	        this.setLocation(x, y);
	        this.setAnimationFrame(0, 0);
	}

}
