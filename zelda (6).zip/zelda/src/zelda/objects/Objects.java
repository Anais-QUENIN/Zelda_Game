package zelda.objects;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;

import com.golden.gamedev.object.AnimatedSprite;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.object.SpriteGroup;

import zelda.Zelda;
import zelda.scenary.Board;

public abstract class Objects extends AnimatedSprite{
	
	protected SpriteGroup sprites;
	
	 protected Zelda game;
	 
	 protected boolean isImmune;
		
	 protected long immuneTimer; 
	 
	 protected boolean visibilite;
	 protected Board board;
	 protected boolean recup;
	 protected int onceTimer = 100;
	 
	 public boolean getImmune() {
		 return this.isImmune;
	 }
	 
	 public void setVisibilite(boolean bool) {
		 if (!isImmune) {
	            isImmune = true;
	            immuneTimer = System.currentTimeMillis() + 1000; // l'immunité dure 3 secondes
	        }
		 this.visibilite=bool;
	 }
	 
	 public boolean once = false;
	 
	 public void setRecup(boolean bool) {
		 if(!once) {
			 System.out.println("once is: " + once);
		 if(!isImmune) {
			 this.recup=bool;
			
		 }
		 once = true;
	     onceTimer = 100;}
	 }
	 
	 public boolean estRecup() {
		 
		 return this.recup;
	 }
	 
	 public boolean getVisibilite() {
		 return this.visibilite;
	 }
	 
	 public void render(Graphics2D g) {
	        super.render(g);
	    }
	 
	 public void setBoard(Board board) {
			this.board=board;
	    }
	 
	 
	 public void update(long elapsedTime) {
	        super.update(elapsedTime);
	        if (isImmune && System.currentTimeMillis() > immuneTimer) {
	            isImmune = false;
	        }}
	
	 public static BufferedImage toBufferedImage(Image img)
	    {
	        if (img instanceof BufferedImage)
	        {
	            return (BufferedImage) img;
	        }

	        // Create a buffered image with transparency
	        BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);

	        // Draw the image on to the buffered image
	        Graphics2D bGr = bimage.createGraphics();
	        bGr.drawImage(img, 0, 0, null);
	        bGr.dispose();

	        // Return the buffered image
	        return bimage;
	    }

}
