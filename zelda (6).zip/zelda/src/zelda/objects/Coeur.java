package zelda.objects;

import java.awt.image.BufferedImage;

import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.object.SpriteGroup;

import zelda.Zelda;
import zelda.enemies.Ennemies;
import zelda.scenary.QuestMenu;

public class Coeur extends Objects {

	public Coeur(Zelda game, double x, double y) {
		this.game = game;
		this.visibilite=false;
		this.recup=false;
		this.isImmune = false;
        this.immuneTimer = 0;
		BufferedImage[] sprites = new BufferedImage[1];
        sprites[0] = Ennemies.toBufferedImage(this.game.getImage("res/sprites/Objects/ORH.GIF").getScaledInstance(25, 25, 15));
        this.setImages(sprites);
        this.setLocation(x, y);
        this.setAnimationFrame(0, 0);
	}
	
}
