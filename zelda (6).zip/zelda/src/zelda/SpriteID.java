package zelda;

public interface SpriteID {

    public static final int GREEN_ROCK_1_ID = 0;
    public static final int GREEN_ROCK_2_ID = 1;
    public static final int GREEN_ROCK_3_ID = 2;
    public static final int GREEN_ROCK_4_ID = 3;
    public static final int GREEN_ROCK_5_ID = 4;
    public static final int GREEN_ROCK_6_ID = 5;
    public static final int GREEN_ROCK_7_ID = 6;
    public static final int SAND_ROCK_1_ID = 7;
    public static final int SAND_ROCK_2_ID = 8;
    public static final int SAND_ROCK_3_ID = 9;
    public static final int SAND_ROCK_4_ID = 10;
    public static final int SAND_ROCK_5_ID = 11;
    public static final int SAND_ROCK_6_ID = 12;
    public static final int SAND_ROCK_7_ID = 13;
    public static final int DARK_ROCK_1_ID = 14;
    public static final int DARK_ROCK_2_ID = 15;
    public static final int DARK_ROCK_3_ID = 16;
    public static final int DARK_ROCK_4_ID = 17;
    public static final int DARK_ROCK_5_ID = 18;
    public static final int DARK_ROCK_6_ID = 19;
    public static final int DARK_ROCK_7_ID = 20;
    public static final int OUTSIDE_DOOR_ID = 21;
    public static final int SAND_FLOOR_ID = 22;
    
}
